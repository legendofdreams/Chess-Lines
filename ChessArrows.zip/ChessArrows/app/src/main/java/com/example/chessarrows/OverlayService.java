package com.example.chessarrows;
import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.app.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.os.IBinder;
import android.view.*;
import android.text.SpannableString;
import android.text.style.RelativeSizeSpan;
import android.widget.FrameLayout;
import android.widget.TextView;

public class OverlayService extends Service {
    static final String A_GEST = "chessarrows.GEST", A_PANEL = "chessarrows.PANEL", A_EXIT = "chessarrows.EXIT";
    private WindowManager wm;
    private ArrowView canvas;
    private WindowManager.LayoutParams cp, pp;
    private FrameLayout panel;
    private TextView main, itemGest;
    private final java.util.List<View> items = new java.util.ArrayList<>();
    private boolean expanded;
    private float cxm, cym;
    private int sw, sh;
    private boolean drawMode = true, controller, panelAttached;
    private SharedPreferences prefs;

    @Override public IBinder onBind(Intent i) { return null; }

    @Override public int onStartCommand(Intent i, int f, int id) {
        String act = i == null ? null : i.getAction();
        if (canvas != null) {
            if (A_GEST.equals(act)) setGestures(!drawMode);
            else if (A_PANEL.equals(act)) { if (panelAttached) hidePanel(); else showPanel(); }
            else if (A_EXIT.equals(act)) stopSelf();
            else if (i != null && i.getBooleanExtra("calibrate", false)) canvas.startCalibration();
            return START_STICKY;
        }
        prefs = getSharedPreferences("p", MODE_PRIVATE);
        getSystemService(NotificationManager.class)
                .createNotificationChannel(new NotificationChannel("ov", "Overlay", NotificationManager.IMPORTANCE_LOW));
        startForeground(1, new Notification.Builder(this, "ov")
                .setContentTitle("Chess Arrows работает").setSmallIcon(android.R.drawable.ic_menu_edit)
                .addAction(android.R.drawable.ic_menu_edit, "Жесты", pi(A_GEST, 1))
                .addAction(android.R.drawable.ic_menu_view, "Кнопка", pi(A_PANEL, 2))
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Выход", pi(A_EXIT, 3)).build());

        wm = getSystemService(WindowManager.class);
        BoardGeometry g = BoardGeometry.load(this);
        canvas = new ArrowView(this, g, prefs.getInt("color", Color.GREEN),
                prefs.getInt("width", Math.round(g.cell * 0.1f)), prefs.getInt("head", Math.round(g.cell * 0.4f)),
                prefs.getBoolean("snap", true));
        TouchService ts = TouchService.instance;
        controller = ts != null && ts.startControl(new TouchService.Sink() {
            public void feed(MotionEvent e) { if (canvas != null) canvas.onTouchEvent(e); }
            public boolean calibrating() { return canvas != null && canvas.isCalibrating(); }
        }, prefs.getInt("hold", 500));
        canvas.stroke = controller ? null : this::replay;
        cp = new WindowManager.LayoutParams(-1, -1, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT);
        if (controller) cp.flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        wm.addView(canvas, cp);

        buildPanel(g);
        if (prefs.getBoolean("float", true)) showPanel();
        if (i != null && i.getBooleanExtra("calibrate", false)) canvas.startCalibration();
        setGestures(true);
        return START_STICKY;
    }

    private PendingIntent pi(String action, int code) {
        return PendingIntent.getService(this, code, new Intent(this, OverlayService.class).setAction(action),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    private SpannableString label(String icon, String text) {
        SpannableString ss = new SpannableString(icon + "\n" + text);
        ss.setSpan(new RelativeSizeSpan(2.2f), 0, icon.length(), 0);
        return ss;
    }

    private GradientDrawable oval(int color) {
        GradientDrawable o = new GradientDrawable(); o.setShape(GradientDrawable.OVAL); o.setColor(color); return o;
    }

    private TextView item(String icon, String text, View.OnClickListener l) {
        TextView v = new TextView(this);
        v.setText(label(icon, text)); v.setTextColor(Color.WHITE); v.setTextSize(10); v.setGravity(Gravity.CENTER);
        v.setBackground(oval(0xEE263238)); v.setVisibility(View.GONE);
        v.setOnClickListener(x -> { setExpanded(false); l.onClick(x); });
        items.add(v);
        return v;
    }

    /** Круговое меню: кнопка в центре, 5 действий по окружности, без прокрутки. */
    private void buildPanel(BoardGeometry g) {
        sw = g.sw; sh = g.sh; cxm = sw - dp(40); cym = dp(160);
        final int S = dp(250), size = dp(60), R = dp(88);
        panel = new FrameLayout(this);
        main = new TextView(this);
        main.setTextColor(Color.WHITE); main.setTextSize(24); main.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams mp = new FrameLayout.LayoutParams(dp(52), dp(52), Gravity.CENTER);

        itemGest = item("✋", "Жесты", v -> setGestures(!drawMode));
        View[] ring = {
                item("🗑", "Стереть", v -> canvas.clearAll()),
                item("↩", "Назад", v -> canvas.undoLast()),
                itemGest,
                item("🙈", "Скрыть", v -> hidePanel()),
                item("✕", "Выход", v -> stopSelf())};
        for (int k = 0; k < ring.length; k++) {
            double a = Math.toRadians(-90 + 360.0 / ring.length * k);
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(size, size, Gravity.TOP | Gravity.START);
            lp.leftMargin = (int) (S / 2 + R * Math.cos(a) - size / 2);
            lp.topMargin = (int) (S / 2 + R * Math.sin(a) - size / 2);
            panel.addView(ring[k], lp);
        }
        panel.addView(main, mp);

        pp = new WindowManager.LayoutParams(dp(52), dp(52), WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT);
        pp.gravity = Gravity.TOP | Gravity.START;
        applyLayout();

        final float[] d = new float[4]; final boolean[] moved = {false};
        main.setOnTouchListener((v, e) -> {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN: d[0] = e.getRawX(); d[1] = e.getRawY(); d[2] = cxm; d[3] = cym; moved[0] = false; return true;
                case MotionEvent.ACTION_MOVE:
                    if (Math.abs(e.getRawX() - d[0]) > dp(6) || Math.abs(e.getRawY() - d[1]) > dp(6)) moved[0] = true;
                    if (moved[0]) { cxm = d[2] + e.getRawX() - d[0]; cym = d[3] + e.getRawY() - d[1]; applyLayout(); }
                    return true;
                case MotionEvent.ACTION_UP:
                    if (!moved[0]) setExpanded(!expanded);
                    return true;
            }
            return true;
        });
    }

    private void setExpanded(boolean e) {
        expanded = e;
        for (View v : items) v.setVisibility(e ? View.VISIBLE : View.GONE);
        pp.width = pp.height = e ? dp(250) : dp(52);
        applyLayout();
    }

    private void applyLayout() {
        pp.x = (int) Math.max(0, Math.min(sw - pp.width, cxm - pp.width / 2f));
        pp.y = (int) Math.max(0, Math.min(sh - pp.height, cym - pp.height / 2f));
        if (panelAttached) wm.updateViewLayout(panel, pp);
    }

    private void showPanel() { if (!panelAttached) { wm.addView(panel, pp); panelAttached = true; } }
    private void hidePanel() {
        if (panelAttached) { setExpanded(false); wm.removeView(panel); panelAttached = false; }
    }

    private void setGestures(boolean on) {
        drawMode = on;
        main.setText(on ? "✎" : "⏸");
        main.setBackground(oval(on ? 0xDD2E7D32 : 0xDD616161));
        itemGest.setText(label(on ? "✋" : "🚫", on ? "Жесты" : "Выкл"));
        if (controller) { if (TouchService.instance != null) TouchService.instance.drawEnabled = on; }
        else setTouchable(on);
    }

    private void setTouchable(boolean t) {
        if (canvas == null) return;
        if (t) cp.flags &= ~WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        else cp.flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        wm.updateViewLayout(canvas, cp);
    }

    /** Запасной режим (Android < 10): повтор одиночного жеста через Accessibility. */
    private void replay(float x1, float y1, float x2, float y2, long dur) {
        TouchService s = TouchService.instance;
        if (s == null) return;
        setTouchable(false);
        Path path = new Path();
        path.moveTo(x1, y1);
        if (Math.hypot(x2 - x1, y2 - y1) > 12) path.lineTo(x2, y2);
        long d = Math.max(30, Math.min(dur, 600));
        boolean ok = s.dispatchGesture(new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(path, 0, d)).build(),
                new AccessibilityService.GestureResultCallback() {
                    @Override public void onCompleted(GestureDescription g) { setTouchable(drawMode); }
                    @Override public void onCancelled(GestureDescription g) { setTouchable(drawMode); }
                }, null);
        if (!ok) setTouchable(drawMode);
    }

    @Override public void onDestroy() {
        if (controller && TouchService.instance != null) TouchService.instance.stopControl();
        if (canvas != null) { hidePanel(); wm.removeView(canvas); canvas = null; }
        super.onDestroy();
    }
}
