package com.example.chessarrows;
import android.app.Activity;
import android.content.*;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    private SharedPreferences p;
    private TextView status;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        p = getSharedPreferences("p", MODE_PRIVATE);
        if (android.os.Build.VERSION.SDK_INT >= 33)
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 1);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL); root.setPadding(40, 60, 40, 40);
        ScrollView sv = new ScrollView(this); sv.addView(root); setContentView(sv);

        status = new TextView(this); root.addView(status);
        root.addView(btn("Разрешение «Поверх других окон»", v -> startActivity(new Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())))));
        root.addView(btn("Включить службу Accessibility", v ->
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))));

        root.addView(label("Цвет"));
        LinearLayout row = new LinearLayout(this);
        int[] cols = {Color.GREEN, Color.RED, Color.YELLOW, Color.BLUE};
        String[] names = {"Зелёный", "Красный", "Жёлтый", "Синий"};
        for (int i = 0; i < 4; i++) {
            final int c = cols[i];
            Button x = btn(names[i], v -> { p.edit().putInt("color", c).apply(); refresh(); });
            x.setBackgroundColor(c); x.setTextColor(c == Color.BLUE || c == Color.RED ? Color.WHITE : Color.BLACK);
            x.setTextSize(11);
            row.addView(x, new LinearLayout.LayoutParams(0, -2, 1));
        }
        root.addView(row);
        BoardGeometry g = BoardGeometry.load(this);
        root.addView(label("Толщина линии"));
        root.addView(seek("width", 4, 40, Math.round(g.cell * 0.1f)));
        root.addView(label("Окно ожидания второго пальца, мс (дольше удержишь один палец — он уйдёт в игру)"));
        root.addView(seek("hold", 150, 1000, 500));
        root.addView(label("Размер наконечника"));
        root.addView(seek("head", 20, 120, Math.round(g.cell * 0.4f)));
        root.addView(check("snap", "Кончик стрелки липнет к центру клетки при отпускании", true));
        root.addView(check("float", "Показывать плавающую кнопку управления", true));
        root.addView(check("flip", "Играю чёрными (доска перевёрнута)", false));
        root.addView(btn("Калибровка доски (2 касания по углам)", v -> {
            if (!Settings.canDrawOverlays(this)) { refresh(); return; }
            stopService(new Intent(this, OverlayService.class));
            startForegroundService(new Intent(this, OverlayService.class).putExtra("calibrate", true));
            moveTaskToBack(true);
        }));
        root.addView(btn("Сбросить калибровку (авто по экрану)", v -> { BoardGeometry.resetSaved(this); refresh(); }));

        Button go = btn("Запустить оверлей", v -> {
            if (!Settings.canDrawOverlays(this)) { refresh(); return; }
            if (!accOn()) { Toast.makeText(this, "Сначала включите службу Accessibility", Toast.LENGTH_LONG).show();
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)); return; }
            startForegroundService(new Intent(this, OverlayService.class));
            moveTaskToBack(true);
        });
        root.addView(go);
        root.addView(btn("Остановить оверлей", v -> stopService(new Intent(this, OverlayService.class))));
    }

    @Override protected void onResume() { super.onResume(); refresh(); }

    private void refresh() {
        boolean o = Settings.canDrawOverlays(this);
        BoardGeometry g0 = BoardGeometry.load(this);
        String en = Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        boolean a = en != null && en.contains(getPackageName());
        status.setText("Поверх окон: " + (o ? "✅" : "❌ нужно") + "\nAccessibility: " + (a ? "✅" : "❌ нужно")
                + "\nЭкран: " + g0.sw + "x" + g0.sh + ", клетка ≈ " + Math.round(g0.cell) + " px, верх доски y=" + Math.round(g0.top)
                + "\nЦвет сохранён: #" + Integer.toHexString(p.getInt("color", Color.GREEN)).substring(2));
    }

    private boolean accOn() {
        String en = Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        return en != null && en.contains(getPackageName());
    }
    private Button btn(String t, View.OnClickListener l) { Button b = new Button(this); b.setText(t); b.setOnClickListener(l); return b; }
    private CheckBox check(String key, String t, boolean def) {
        CheckBox c = new CheckBox(this); c.setText(t); c.setChecked(p.getBoolean(key, def));
        c.setOnCheckedChangeListener((b, v) -> p.edit().putBoolean(key, v).apply());
        return c;
    }
    private TextView label(String t) { TextView v = new TextView(this); v.setText(t); v.setPadding(0, 30, 0, 0); return v; }
    private SeekBar seek(String key, int min, int max, int def) {
        SeekBar s = new SeekBar(this); s.setMax(max - min); s.setProgress(p.getInt(key, def) - min);
        s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar sb, int v, boolean u) { p.edit().putInt(key, v + min).apply(); }
            public void onStartTrackingTouch(SeekBar sb) {}
            public void onStopTrackingTouch(SeekBar sb) {}
        });
        return s;
    }
}
