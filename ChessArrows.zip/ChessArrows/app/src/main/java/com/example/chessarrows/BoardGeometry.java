package com.example.chessarrows;
import android.content.Context;
import android.content.SharedPreferences;
import android.util.DisplayMetrics;
import android.view.WindowManager;

/** Геометрия доски: берётся из реального разрешения экрана, либо из калибровки. */
public class BoardGeometry {
    // Пропорции по скриншоту Chess.com (1080x2376): доска во всю ширину,
    // верхний край на 787 px = 0.3312 высоты экрана, клетка = ширина/8 = 135 px.
    static final float TOP_RATIO = 787f / 2376f;
    public float left, top, cell;
    public int sw, sh;

    public static BoardGeometry load(Context c) {
        BoardGeometry g = new BoardGeometry();
        DisplayMetrics dm = new DisplayMetrics();
        ((WindowManager) c.getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay().getRealMetrics(dm);
        g.sw = dm.widthPixels; g.sh = dm.heightPixels;
        SharedPreferences p = c.getSharedPreferences("p", Context.MODE_PRIVATE);
        if (p.contains("b_cell") && p.getInt("b_sw", 0) == g.sw && p.getInt("b_sh", 0) == g.sh) {
            g.left = p.getFloat("b_left", 0); g.top = p.getFloat("b_top", 0); g.cell = p.getFloat("b_cell", 1);
        } else {
            g.cell = Math.min(g.sw, g.sh) / 8f;
            g.left = (g.sw - g.cell * 8) / 2f;
            g.top = g.sh * TOP_RATIO;
        }
        return g;
    }

    public void save(Context c) {
        c.getSharedPreferences("p", Context.MODE_PRIVATE).edit().putFloat("b_left", left).putFloat("b_top", top)
                .putFloat("b_cell", cell).putInt("b_sw", sw).putInt("b_sh", sh).apply();
    }

    public static void resetSaved(Context c) {
        c.getSharedPreferences("p", Context.MODE_PRIVATE).edit().remove("b_cell").apply();
    }

    public int col(float x) { return Math.max(0, Math.min(7, (int) Math.floor((x - left) / cell))); }
    public int row(float y) { return Math.max(0, Math.min(7, (int) Math.floor((y - top) / cell))); }
    public float cx(int col) { return left + (col + 0.5f) * cell; }
    public float cy(int row) { return top + (row + 0.5f) * cell; }

    /** Допустимое направление: ладья/слон/ферзь (линии, диагонали) или конь (Г). */
    public static boolean valid(int c1, int r1, int c2, int r2) {
        int dc = Math.abs(c2 - c1), dr = Math.abs(r2 - r1);
        if (dc == 0 && dr == 0) return false;
        return dc == 0 || dr == 0 || dc == dr || (dc == 1 && dr == 2) || (dc == 2 && dr == 1);
    }

    public static String square(int col, int row, boolean flip) {
        int f = flip ? 7 - col : col, r = flip ? row + 1 : 8 - row;
        return "" + (char) ('a' + f) + r;
    }
}
