package com.example.chessarrows;
import android.content.Context;
import android.graphics.*;
import android.view.MotionEvent;
import android.view.View;
import java.util.ArrayList;
import java.util.List;

public class ArrowView extends View {
    public interface Stroke { void onSingle(float x1, float y1, float x2, float y2, long dur); }
    public interface Calib { void onDone(); }
    public Stroke stroke;
    public Calib calib;
    public BoardGeometry geo;
    private final boolean snap;
    private final List<float[]> arrows = new ArrayList<>(); // {x1,y1,x2,y2} в пикселях
    private float[] cur;
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG), fill = new Paint(Paint.ANTI_ALIAS_FLAG),
            hl = new Paint(), grid = new Paint(), txt = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path tri = new Path();
    private final float head;
    private float sx, sy, rx, ry, lrx, lry;
    private int secondId = -1, color;
    private boolean multi, cleared, calibrating;
    private final List<float[]> cpts = new ArrayList<>();
    private long t0;

    public ArrowView(Context c, BoardGeometry g, int color, float width, float headSize, boolean snap) {
        super(c);
        geo = g; head = headSize; this.snap = snap; this.color = color;
        line.setColor(color); line.setStrokeWidth(width); line.setStrokeCap(Paint.Cap.ROUND); line.setAlpha(210);
        fill.setColor(color); fill.setStyle(Paint.Style.FILL); fill.setAlpha(210);
        hl.setColor(color); hl.setAlpha(80);
        grid.setColor(Color.WHITE); grid.setStrokeWidth(2);
        txt.setColor(Color.WHITE); txt.setTextSize(46); txt.setShadowLayer(6, 0, 0, Color.BLACK);
    }

    public void clearAll() { arrows.clear(); cur = null; invalidate(); }
    public void undoLast() { if (!arrows.isEmpty()) arrows.remove(arrows.size() - 1); invalidate(); }
    public boolean isCalibrating() { return calibrating; }
    public void startCalibration() { calibrating = true; cpts.clear(); arrows.clear(); cur = null; invalidate(); }

    @Override public boolean onTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                sx = e.getX(); sy = e.getY(); rx = lrx = e.getRawX(); ry = lry = e.getRawY();
                t0 = e.getEventTime(); multi = false; cleared = false; cur = null; secondId = -1;
                return true;
            case MotionEvent.ACTION_POINTER_DOWN: {
                multi = true;
                int n = e.getPointerCount();
                if (calibrating) break;
                if (n >= 4) { arrows.clear(); cur = null; cleared = true; invalidate(); break; }
                if (n == 2 && !cleared) {
                    int i = e.getActionIndex();
                    secondId = e.getPointerId(i);
                    cur = snap ? new float[]{geo.cx(geo.col(sx)), geo.cy(geo.row(sy)), e.getX(i), e.getY(i)}
                            : new float[]{sx, sy, e.getX(i), e.getY(i)};
                    invalidate();
                }
                break;
            }
            case MotionEvent.ACTION_MOVE:
                if (!multi) { lrx = e.getRawX(); lry = e.getRawY(); }
                else if (cur != null) {
                    int i = e.findPointerIndex(secondId);
                    if (i >= 0) { cur[2] = e.getX(i); cur[3] = e.getY(i); invalidate(); }
                }
                break;
            case MotionEvent.ACTION_POINTER_UP: commit(); break;
            case MotionEvent.ACTION_UP:
                commit();
                if (calibrating && !multi) { calibTap(e.getX(), e.getY()); break; }
                if (!multi && stroke != null) stroke.onSingle(rx, ry, lrx, lry, e.getEventTime() - t0);
                break;
            case MotionEvent.ACTION_CANCEL: cur = null; invalidate(); break;
        }
        return true;
    }

    private void calibTap(float x, float y) {
        cpts.add(new float[]{x, y});
        if (cpts.size() == 2) {
            float l = Math.min(cpts.get(0)[0], cpts.get(1)[0]), r = Math.max(cpts.get(0)[0], cpts.get(1)[0]);
            float t = Math.min(cpts.get(0)[1], cpts.get(1)[1]);
            if (r - l > 200) { geo.left = l; geo.top = t; geo.cell = (r - l) / 8f; geo.save(getContext()); }
            calibrating = false; cpts.clear();
            if (calib != null) calib.onDone();
        }
        invalidate();
    }

    private void commit() {
        if (cur != null) {
            // Во время рисования кончик идёт ровно за пальцем; при отпускании (если включено) липнет к центру клетки.
            if (snap) { cur[2] = geo.cx(geo.col(cur[2])); cur[3] = geo.cy(geo.row(cur[3])); }
            if (Math.hypot(cur[2] - cur[0], cur[3] - cur[1]) > 20) arrows.add(cur);
            cur = null; invalidate();
        }
    }

    @Override protected void onDraw(Canvas c) {
        if (calibrating) {
            for (int i = 0; i <= 8; i++) {
                c.drawLine(geo.left + i * geo.cell, geo.top, geo.left + i * geo.cell, geo.top + 8 * geo.cell, grid);
                c.drawLine(geo.left, geo.top + i * geo.cell, geo.left + 8 * geo.cell, geo.top + i * geo.cell, grid);
            }
            c.drawText(cpts.isEmpty() ? "Коснитесь ЛЕВОГО ВЕРХНЕГО угла доски" : "Коснитесь ПРАВОГО НИЖНЕГО угла доски",
                    30, geo.top - 40, txt);
            return;
        }
        for (float[] a : arrows) draw(c, a, 210);
        if (cur != null) {
            c.drawRect(cell(geo.col(cur[0]), geo.row(cur[1])), hl);
            c.drawRect(cell(geo.col(cur[2]), geo.row(cur[3])), hl);
            draw(c, cur, 210);
        }
    }

    private RectF cell(int col, int row) {
        return new RectF(geo.left + col * geo.cell, geo.top + row * geo.cell,
                geo.left + (col + 1) * geo.cell, geo.top + (row + 1) * geo.cell);
    }

    // Стрелка строго прямая, от начальной клетки к пальцу.
    private void draw(Canvas c, float[] a, int alpha) {
        float x1 = a[0], y1 = a[1], x2 = a[2], y2 = a[3];
        float dx = x2 - x1, dy = y2 - y1, len = (float) Math.hypot(dx, dy);
        if (len < 1) return;
        line.setAlpha(alpha); fill.setAlpha(alpha);
        float ux = dx / len, uy = dy / len, h = Math.min(head, len);
        float bx = x2 - ux * h * 0.8f, by = y2 - uy * h * 0.8f;
        c.drawLine(x1, y1, bx, by, line);
        tri.reset();
        tri.moveTo(x2, y2);
        tri.lineTo(bx - uy * h * 0.5f, by + ux * h * 0.5f);
        tri.lineTo(bx + uy * h * 0.5f, by - ux * h * 0.5f);
        tri.close();
        c.drawPath(tri, fill);
    }
}
