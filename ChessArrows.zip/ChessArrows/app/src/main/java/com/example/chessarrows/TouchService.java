package com.example.chessarrows;
import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.accessibilityservice.GestureDescription;
import android.accessibilityservice.TouchInteractionController;
import android.graphics.Path;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.Display;
import android.view.MotionEvent;
import android.view.ViewConfiguration;
import android.view.accessibility.AccessibilityEvent;

/**
 * Читает ВСЕ касания (в т.ч. мультитач) через TouchInteractionController, не блокируя игру:
 *  - один палец: сразу отдаётся приложению как обычное касание (перетаскивание фигур идёт вживую);
 *  - второй палец за время «окна ожидания»: касания забирает оверлей и рисует стрелку.
 */
public class TouchService extends AccessibilityService {
    public interface Sink { void feed(MotionEvent e); boolean calibrating(); }

    static TouchService instance;
    public volatile boolean drawEnabled = true;
    private final Handler h = new Handler(Looper.getMainLooper());
    private Object tic, cb;
    private Sink sink;
    private long holdMs = 500;
    private boolean decided;
    private float dx, dy, slop;
    private final Runnable timeout = this::delegate;

    @Override protected void onServiceConnected() { instance = this; }
    @Override public boolean onUnbind(android.content.Intent i) { stopControl(); instance = null; return super.onUnbind(i); }
    @Override public void onAccessibilityEvent(AccessibilityEvent e) {}
    @Override public void onInterrupt() {}

    public boolean startControl(Sink s, long hold) {
        if (Build.VERSION.SDK_INT < 29) return false;
        try {
            sink = s; holdMs = hold;
            slop = ViewConfiguration.get(this).getScaledTouchSlop() * 1.5f;
            AccessibilityServiceInfo info = getServiceInfo();
            info.flags |= AccessibilityServiceInfo.FLAG_REQUEST_TOUCH_EXPLORATION_MODE;
            setServiceInfo(info);
            TouchInteractionController c = getTouchInteractionController(Display.DEFAULT_DISPLAY);
            TouchInteractionController.Callback callback = new TouchInteractionController.Callback() {
                @Override public void onMotionEvent(MotionEvent e) { handle(e); }
                @Override public void onStateChanged(int state) {}
            };
            c.registerCallback(getMainExecutor(), callback);
            tic = c; cb = callback;
            return true;
        } catch (Throwable t) { stopControl(); return false; }
    }

    public void stopControl() {
        try {
            if (tic != null) ((TouchInteractionController) tic).unregisterCallback((TouchInteractionController.Callback) cb);
        } catch (Throwable ignored) {}
        tic = null; cb = null; sink = null;
        h.removeCallbacks(timeout);
        try {
            AccessibilityServiceInfo info = getServiceInfo();
            if (info != null) {
                info.flags &= ~AccessibilityServiceInfo.FLAG_REQUEST_TOUCH_EXPLORATION_MODE;
                setServiceInfo(info);
            }
        } catch (Throwable ignored) {}
    }

    private void delegate() {
        if (decided) return;
        decided = true; h.removeCallbacks(timeout);
        try { ((TouchInteractionController) tic).requestDelegating(); } catch (Throwable ignored) {}
    }

    private void handle(MotionEvent e) {
        int a = e.getActionMasked();
        if (sink == null || !drawEnabled) {            // рисование выключено: всё в приложение
            if (a == MotionEvent.ACTION_DOWN) decided = false;
            delegate();
            return;
        }
        sink.feed(e);
        boolean cal = sink.calibrating();
        switch (a) {
            case MotionEvent.ACTION_DOWN:
                decided = false; dx = e.getX(); dy = e.getY();
                if (!cal) h.postDelayed(timeout, holdMs);
                break;
            case MotionEvent.ACTION_POINTER_DOWN:
                if (!decided) { decided = true; h.removeCallbacks(timeout); }   // второй палец -> рисуем
                break;
            case MotionEvent.ACTION_MOVE:
                if (!decided && !cal && e.getPointerCount() == 1 && Math.hypot(e.getX() - dx, e.getY() - dy) > slop)
                    delegate();                         // перетаскивание фигуры: дальше вживую в приложение
                break;
            case MotionEvent.ACTION_UP:
                h.removeCallbacks(timeout);
                if (!decided && !cal) { decided = true; tap(dx, dy); }     // быстрый тап
                break;
            case MotionEvent.ACTION_CANCEL:
                h.removeCallbacks(timeout); decided = true; break;
        }
    }

    private void tap(float x, float y) {
        Path p = new Path(); p.moveTo(x, y);
        dispatchGesture(new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(p, 0, 40)).build(), null, null);
    }
}
